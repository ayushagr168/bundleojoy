export default [
  [
    { itemName: "Puma", itemColor: "Red" },
    { itemName: "Puma", itemColor: "Red" },
    { itemName: "Puma", itemColor: "Red" },
  ],
  [
    { itemName: "Puma", itemColor: "Red" },
    { itemName: "Puma", itemColor: "Red" },
    { itemName: "Puma", itemColor: "Red" },
  ],
];
