import React, { Component } from 'react';
import Card from './Card';
import List from './List';

class App extends Component {
  render() {
    return (
          <div >
            <List />
          </div>
    );
  }
}

export default App;
